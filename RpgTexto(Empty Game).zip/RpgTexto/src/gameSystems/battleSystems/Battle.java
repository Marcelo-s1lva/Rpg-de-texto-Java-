package gameSystems.battleSystems;

import gameSystems.characterSystem.Character;
import gameSystems.battleSystems.arrayCopy.Copy;
import gameSystems.teamSystem.Team;


public class Battle {
    private Character[] player; //player team
    private Character[] enemy; //enemy team
    private int turns = 0;
    private boolean yourTurn = true;
    private boolean team1IsBot;
    private boolean team2IsBot;


    private void setTeams(Character[] team1, Character[] team2){
        player = Copy.ArrayCopy(team1);
        enemy = Copy.ArrayCopy(team2);
    }


    public Battle (Team team1, Team team2){
        setTeams(team1.getTeamArray(), team2.getTeamArray());
        team1IsBot = team1.isBot();
        team2IsBot = team2.isBot();
    }

    public void Initialize(){
        if (player != null && enemy != null) {
            while (TeamHasAliveCharacter(player) && TeamHasAliveCharacter(enemy)) {

                if (yourTurn) {

                    Manager.selectAction(player, enemy, team1IsBot);

                    Manager.chargeUlti(player);
                    yourTurn = false;

                } else {

                    Manager.selectAction(enemy, player, team2IsBot);
                    Manager.chargeUlti(enemy);
                    yourTurn = true;

                }

                turns++;

            }
        }
        else{
            System.out.println("Some team is Pointing to Null");
        }
    }

    //Verify if team has an alive character
    private boolean TeamHasAliveCharacter(Character[] team){
        for (int i = 0; i < team.length; i++){
            if (!team[i].isDead()){
                return true;
            }
        }
        return false;
    }

    public int GetWinner(){
        if (TeamHasAliveCharacter(player) && !TeamHasAliveCharacter(enemy)){
            return 1;
        }
        else if (!TeamHasAliveCharacter(player) && TeamHasAliveCharacter(enemy)){
            return -1;
        }
        else{
            return 0;
        }
    }

}
