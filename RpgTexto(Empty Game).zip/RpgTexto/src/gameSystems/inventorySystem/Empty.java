package gameSystems.inventorySystem;


public class Empty extends Item{
    public Empty(){
        setId(0);
        setCurrentStack(0);
    }
}
