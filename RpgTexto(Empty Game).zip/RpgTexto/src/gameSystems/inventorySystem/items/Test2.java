package gameSystems.inventorySystem.items;

import gameSystems.inventorySystem.Item;

public class Test2 extends Item {

    public Test2(){
        setId(2);
        addTag("Tag2");
        setName("Other Test Item");
    }
}
