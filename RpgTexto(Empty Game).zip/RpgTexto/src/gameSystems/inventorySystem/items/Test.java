package gameSystems.inventorySystem.items;

import gameSystems.inventorySystem.Item;

public class Test extends Item {

    public Test(){
        setId(1);
        addTag("Tag");
        setName("Test Item");

    }
}
