package gameSystems.dialogueSystem;

import gameSystems.dialogueSystem.dialogues.*;

//This class set the instances of the dialogues to use in Main
public class Dialogues {
    public Dialogue example = new Example();



}
