package gameSystems.dialogueSystem.dialogues;

import gameSystems.dialogueSystem.Dialogue;

public class Example extends Dialogue {
    public Example(){
        textBlocks.add("this is an example of a dialogue in my RPG game");
        textBlocks.add("in this dialogue system, you can easily create and run a dialogue");
        endMessage = "Enjoy it :)";
    }
}
