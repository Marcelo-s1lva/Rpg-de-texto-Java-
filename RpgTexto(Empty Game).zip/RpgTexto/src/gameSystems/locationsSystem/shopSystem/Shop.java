package gameSystems.locationsSystem.shopSystem;

import gameSystems.inventorySystem.Item;
import gameSystems.locationsSystem.Location;
import gameplay.Player;

import java.util.ArrayList;
import java.util.List;

public abstract class Shop extends Location {
    private List<Item> stock = new ArrayList<>();
    private List<Integer> costs = new ArrayList<>();
    private Player client;


    private void buy(Item itemToBuy, int cost, Player player){
        if (player.getMoney() >= cost){
            player.setMoney(player.getMoney() - cost);
            player.inventory.addItem(itemToBuy);
        }
        else{
            System.out.println("not Enough Money");

        }
    }


    public Player getClient() {
        return client;
    }

    public void setClient(Player client){
        this.client = client;
    }

    protected void addItem(Item item, int cost){
        stock.add(item);
        costs.add(cost);
    }

    protected void buyItem(int selectedItem){
        if (selectedItem < stock.size() && client != null){
            buy(stock.get(selectedItem), costs.get(selectedItem),client);
        }
    }

}
