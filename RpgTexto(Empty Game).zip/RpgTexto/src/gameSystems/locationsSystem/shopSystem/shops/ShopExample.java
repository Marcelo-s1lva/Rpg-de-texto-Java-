package gameSystems.locationsSystem.shopSystem.shops;

import gameSystems.inventorySystem.items.*;
import gameSystems.locationsSystem.shopSystem.Shop;


public class ShopExample extends Shop {


    public ShopExample(){
        addItem(new Test(), 50);
    }

    @Override
    protected void locationBlock() {
        System.out.println("select an item");

    }


}
