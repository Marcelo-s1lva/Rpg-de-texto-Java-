package gameSystems.locationsSystem;

public class Locations {

}
