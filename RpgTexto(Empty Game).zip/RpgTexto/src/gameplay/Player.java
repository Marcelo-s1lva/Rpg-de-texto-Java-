package gameplay;

import gameSystems.inventorySystem.Inventory;
import gameSystems.teamSystem.Team;

public class Player {
    public Team playerTeam = new Team(5, false);
    public Inventory inventory = new Inventory(30);
    private int Money;

    public void setMoney(int Money){
        this.Money = Money;
    }

    public int getMoney(){
        return Money;
    }

}
