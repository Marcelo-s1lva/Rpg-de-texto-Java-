package gameplay;

import gameSystems.dialogueSystem.Dialogues;

public class Gameplay {
    public static Dialogues dialogues = new Dialogues();
    public static Player mainPlayer = new Player();
}
